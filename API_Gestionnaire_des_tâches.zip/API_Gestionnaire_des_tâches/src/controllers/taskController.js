const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const taskService = require('../services/taskService');

exports.createTask = async (req, res, next) => {
    try {
        const { title, description, status, priority } = req.body;

        if (!title) {
            return res.status(400).json({ error: "Le titre est obligatoire" });
        }

        const newTask = await prisma.task.create({
            data: { title, description, status, priority, userId: req.user.userId }
        });

        res.status(201).json(newTask);
    } catch (error) {
        next(error);
    }
};

exports.getUserTasks = async (req, res, next) => {
    try {
        const tasks = await prisma.task.findMany({
            where: { userId: req.user.userId },
            include: { tags: true }
        });

        res.json(tasks);
    } catch (error) {
        next(error);
    }
};


exports.getTaskById = async (req, res, next) => {
    try {
        const task = await taskService.getTaskById(parseInt(req.params.id));
        if (!task) {
            return res.status(404).json({ error: "Tâche non trouvée" });
        }
        res.json(task);
    } catch (error) {
        next(error);
    }
};

exports.updateTask = async (req, res, next) => {
    try {
        const updatedTask = await taskService.updateTask(parseInt(req.params.id), req.body);
        res.json(updatedTask);
    } catch (error) {
        next(error);
    }
};

exports.deleteTask = async (req, res, next) => {
    try {
        await taskService.deleteTask(parseInt(req.params.id));
        res.json({ message: "Tâche supprimée avec succès" });
    } catch (error) {
        next(error);
    }
};

exports.getAllTasks = async (req, res, next) => {
    try {
        const { page, sortBy, order } = req.query;

        const tasks = await taskService.getAllTasks(
            parseInt(page) || 1,
            sortBy || "priority",
            order || "desc"
        );

        res.json(tasks);
    } catch (error) {
        next(error);
    }
};

