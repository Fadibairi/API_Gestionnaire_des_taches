const authService = require('../services/authService');

exports.register = async (req, res, next) => {
    try {
        console.log("Requête reçue :", req.body);

        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ error: "Nom d'utilisateur et mot de passe requis" });
        }

        const user = await authService.register(username, password);
        res.status(201).json({ message: "Utilisateur créé avec succès", user });
    } catch (error) {
        next(error);
    }
};


exports.login = async (req, res, next) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ error: "Nom d'utilisateur et mot de passe requis" });
        }

        const { token, user } = await authService.login(username, password);
        res.json({ message: "Connexion réussie", token, user });
    } catch (error) {
        next(error);
    }
};
