const tagService = require('../services/tagService');

exports.createTag = async (req, res, next) => {
    try {
        const { title } = req.body;
        if (!title) {
            return res.status(400).json({ error: "Le titre du tag est obligatoire" });
        }

        const newTag = await tagService.createTag(title);
        res.status(201).json(newTag);
    } catch (error) {
        next(error);
    }
};

exports.getAllTags = async (req, res, next) => {
    try {
        const tags = await tagService.getAllTags();

        if (tags.length === 0) {
            return res.status(404).json({ message: "Aucun tag trouvé" });
        }

        res.json(tags);
    } catch (error) {
        next(error);
    }
};


exports.addTagToTask = async (req, res, next) => {
    try {
        const { taskId, tagId } = req.params;

        const updatedTask = await tagService.addTagToTask(parseInt(taskId), parseInt(tagId));

        res.json({
            message: "Tag ajouté avec succès à la tâche",
            task: updatedTask
        });
    } catch (error) {
        next(error);
    }
};

exports.getTasksByTag = async (req, res, next) => {
    try {
        const { tag } = req.query;
        if (!tag) {
            return res.status(400).json({ error: "Veuillez spécifier un tag pour filtrer" });
        }

        const tasks = await tagService.getTasksByTag(tag);
        res.json(tasks);
    } catch (error) {
        next(error);
    }
};
