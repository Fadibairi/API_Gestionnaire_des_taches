const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

// Créer un tag
exports.createTag = async (title) => {
    return await prisma.tag.create({ data: { title } });
};

//J'ai ajouté cette méthode pour m'aider à vérifier le bon fonctionnement des autres méthodes.
exports.getAllTags = async () => {
    return await prisma.tag.findMany(); // Récupère tous les tags
};


// Associer un tag à une tâche
exports.addTagToTask = async (taskId, tagId) => {
    return await prisma.task.update({
        where: { id: taskId },
        data: {
            tags: {
                connect: { id: tagId }  // Connecte le tag à la tâche
            }
        },
        include: { tags: true } // Retourne les tags associés
    });
};

// Filtrer les tâches par tag
exports.getTasksByTag = async (tagTitle) => {
    return await prisma.task.findMany({
        where: { tags: { some: { title: tagTitle } } },
        include: { tags: true }
    });
};
