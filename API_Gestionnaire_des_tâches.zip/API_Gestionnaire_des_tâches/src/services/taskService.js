const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

exports.createTask = async (data) => {
    return await prisma.task.create({ data });
};

exports.getTaskById = async (id) => {
    return await prisma.task.findUnique({ where: { id } });
};

exports.updateTask = async (id, data) => {
    return await prisma.task.update({ where: { id }, data });
};

exports.deleteTask = async (id) => {
    return await prisma.task.delete({ where: { id } });
};

exports.getAllTasks = async (page = 1, sortBy = "priority", order = "desc") => {
    const tasksPerPage = 10; // Nombre de tâches par page
    const skip = (page - 1) * tasksPerPage;

    return await prisma.task.findMany({
        orderBy: {
            [sortBy]: order // Trier selon la colonne (priority) et l'ordre (desc)
        },
        take: tasksPerPage, // Nombre de tâches à récupérer
        skip: skip // Sauter les tâches des pages précédentes
    });
};

