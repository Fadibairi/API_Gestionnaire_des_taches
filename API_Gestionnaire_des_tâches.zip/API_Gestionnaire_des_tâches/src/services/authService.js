const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const prisma = new PrismaClient();
const SECRET_KEY = process.env.JWT_SECRET || "supersecretkey";

// Inscription d'un utilisateur
exports.register = async (username, password) => {
    const hashedPassword = await bcrypt.hash(password, 10);

    return await prisma.user.create({
        data: { username, password: hashedPassword }
    });
};

// Connexion d'un utilisateur
exports.login = async (username, password) => {
    const user = await prisma.user.findUnique({ where: { username } });

    if (!user || !await bcrypt.compare(password, user.password)) {
        throw new Error("Nom d'utilisateur ou mot de passe incorrect");
    }

    // Générer un token JWT
    const token = jwt.sign({ userId: user.id, username: user.username }, SECRET_KEY, { expiresIn: '1h' });

    return { token, user };
};

// Vérifier un utilisateur depuis son token
exports.verifyToken = (token) => {
    try {
        return jwt.verify(token, SECRET_KEY);
    } catch (error) {
        return null;
    }
};
