const express = require('express');
const tagController = require('../controllers/tagController');

const router = express.Router();
// endpoints 
router.post('/', tagController.createTag);
router.get('/', tagController.getAllTags);
router.post('/assign/:taskId/:tagId', tagController.addTagToTask);
router.get('/filter', tagController.getTasksByTag);

module.exports = router;
