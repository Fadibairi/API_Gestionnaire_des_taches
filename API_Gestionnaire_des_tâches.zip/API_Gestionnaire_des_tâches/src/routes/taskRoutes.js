const express = require('express');
const taskController = require('../controllers/taskController');
const authMiddleware = require('../middlewares/authMiddleware');


const router = express.Router();

router.post('/', authMiddleware.authenticate, taskController.createTask);
router.get('/', authMiddleware.authenticate, taskController.getUserTasks);

//router.post('/', taskController.createTask);
router.get('/', taskController.getAllTasks);
router.get('/:id', taskController.getTaskById);
router.put('/:id', taskController.updateTask);
router.delete('/:id', taskController.deleteTask);


module.exports = router;
