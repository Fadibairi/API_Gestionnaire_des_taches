const express = require('express');
const taskRoutes = require('./routes/taskRoutes');
const errorHandler = require('./middlewares/errorHandler');

const app = express();
const tagRoutes = require('./routes/tagRoutes');
const authRoutes = require('./routes/authRoutes');



app.use(express.json());
app.use('/tasks', taskRoutes);
app.use('/tags', tagRoutes);
app.use('/auth', authRoutes);

app.use(errorHandler);

module.exports = app;
